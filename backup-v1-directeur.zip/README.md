# ERPGestionEtablissementScolaireIIBS_V1_Web
Ce projet consiste à mettre en place une application web pour gérer le role ERP de IIBS Dakar
