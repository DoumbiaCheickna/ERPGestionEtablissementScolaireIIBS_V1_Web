'use client';

import RenderHome from '../pages/Home'

export default function HomePage() {
  return <RenderHome />;
}
