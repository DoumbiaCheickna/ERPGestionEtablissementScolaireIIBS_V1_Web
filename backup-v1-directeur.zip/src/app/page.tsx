"use client";
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from "./admin/auth/login/page";

export default function Home() {
  return <Login />;
  
}
